﻿namespace TestDashboardAndon.Services;

public sealed class AppInstance
{
    public string Id { get; } = System.Guid.NewGuid().ToString("N");
}
