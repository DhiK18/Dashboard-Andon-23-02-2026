﻿using System.Text.Json;

namespace TestDashboardAndon.Services;

public sealed class WsNameStore
{
    private readonly string _filePath;
    private readonly object _lock = new();

    private readonly Dictionary<(string line, int ws), string> _names = new();

    private sealed record Entry(string Line, int Ws, string Name);

    public WsNameStore(IWebHostEnvironment env)
    {
        _filePath = Path.Combine(env.ContentRootPath, "ws-names.json");
        LoadFromDisk();
    }

    public string GetName(string line, int ws)
    {
        lock (_lock)
        {
            // If name is not set, default should be the station number only ("1", "2", ...).
            if (!_names.TryGetValue((line, ws), out var name) || string.IsNullOrWhiteSpace(name))
                return ws.ToString();

            return name.Trim();
        }
    }
    public string GetRawName(string line, int ws)
    {
        lock (_lock)
        {
            return _names.TryGetValue((line, ws), out var name) ? name : string.Empty;
        }
    }

    public void SetName(string line, int ws, string? name)
    {
        lock (_lock)
        {
            var key = (line, ws);
            var nm = NormalizeName(name ?? string.Empty, ws);

            if (string.IsNullOrWhiteSpace(nm))
                _names.Remove(key);
            else
                _names[key] = nm;
        }
    }

    /// <summary>
    /// Historically, station names could be stored like "Station-7 Motor Assy" or "WS-7 Motor Assy".
    /// We normalize by stripping the legacy prefix so the stored value is just the custom name.
    /// </summary>
    private static string NormalizeName(string value, int ws)
    {
        var s = (value ?? string.Empty).Trim();
        if (s.Length == 0) return string.Empty;

        // Strip exact Station-{ws} prefix.
        var stationPrefix = $"Station-{ws}";
        if (s.StartsWith(stationPrefix, StringComparison.OrdinalIgnoreCase))
        {
            s = s.Substring(stationPrefix.Length);
            s = s.TrimStart(' ', '-', ':');
        }

        // Strip exact WS-{ws} prefix.
        var wsPrefix = $"WS-{ws}";
        if (s.StartsWith(wsPrefix, StringComparison.OrdinalIgnoreCase))
        {
            s = s.Substring(wsPrefix.Length);
            s = s.TrimStart(' ', '-', ':');
        }

        // Strip generic "WS-<digits>" if the digits match this station.
        if (s.StartsWith("WS-", StringComparison.OrdinalIgnoreCase))
        {
            var rest = s.Substring(3);
            var i = 0;
            while (i < rest.Length && char.IsDigit(rest[i])) i++;
            if (i > 0 && int.TryParse(rest.Substring(0, i), out var n) && n == ws)
            {
                s = rest.Substring(i);
                s = s.TrimStart(' ', '-', ':');
            }
        }

        return s.Trim();
    }

    public IReadOnlyList<(string Line, int Ws, string Name)> GetAll()
    {
        lock (_lock)
        {
            return _names
                .Select(kv => (kv.Key.line, kv.Key.ws, kv.Value))
                .OrderBy(x => x.line)
                .ThenBy(x => x.ws)
                .ToList();
        }
    }

    public async Task SaveAsync(CancellationToken ct = default)
    {
        List<Entry> data;
        lock (_lock)
        {
            data = _names
                .Select(kv => new Entry(kv.Key.line, kv.Key.ws, kv.Value))
                .OrderBy(e => e.Line)
                .ThenBy(e => e.Ws)
                .ToList();
        }

        var json = JsonSerializer.Serialize(data, new JsonSerializerOptions { WriteIndented = true });
        await File.WriteAllTextAsync(_filePath, json, ct);
    }

    private void LoadFromDisk()
    {
        try
        {
            if (!File.Exists(_filePath)) return;

            var json = File.ReadAllText(_filePath);
            var data = JsonSerializer.Deserialize<List<Entry>>(json) ?? new();

            lock (_lock)
            {
                _names.Clear();
                foreach (var e in data)
                {
                    if (string.IsNullOrWhiteSpace(e.Line)) continue;
                    if (e.Ws <= 0) continue;
                    if (string.IsNullOrWhiteSpace(e.Name)) continue;
                    var nm = NormalizeName(e.Name, e.Ws);
                    if (string.IsNullOrWhiteSpace(nm)) continue;
                    _names[(e.Line.Trim(), e.Ws)] = nm;
                }
            }
        }
        catch
        {
            // ignore corrupt file
        }
    }
}
//WsNameStore.cs
