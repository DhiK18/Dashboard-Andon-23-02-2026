using TestDashboardAndon.Models;

namespace TestDashboardAndon.Services;

public sealed class DashboardState
{
    private LineSnapshot _s2t = new() { Line = "2T" };
    private LineSnapshot _skd = new() { Line = "SKD" };

    // ===== DB STATUS (for UI indicator) =====
    private DbStatus _db = new DbStatus(
        AndonConnected: false,
        TimerConnected: false,
        LastChecked: null,
        LastError: null
    );

    private event Action<DbStatus>? DbChanged;

    // ===== DATA / PIPELINE STATUS (Node-RED -> DB freshness) =====
    private DataStatus _data = new DataStatus(
        LastEventTime: null,
        LastChecked: null,
        LastError: null
    );

    private event Action<DataStatus>? DataChanged;

    private event Action<(LineSnapshot s2t, LineSnapshot skd)>? Changed;

    public IDisposable Subscribe(Action<(LineSnapshot s2t, LineSnapshot skd)> cb)
    {
        Changed += cb;
        cb((_s2t, _skd));

        return new Unsub(() => Changed -= cb);
    }

    public void Update(LineSnapshot s2t, LineSnapshot skd)
    {
        _s2t = s2t;
        _skd = skd;
        Changed?.Invoke((_s2t, _skd));
    }

    public DbStatus ReadDbStatus() => _db;

    public IDisposable SubscribeDb(Action<DbStatus> cb)
    {
        DbChanged += cb;
        cb(_db);
        return new UnsubDb(() => DbChanged -= cb);
    }

    public void UpdateDbStatus(DbStatus status)
    {
        _db = status;
        DbChanged?.Invoke(_db);
    }


    public DataStatus ReadDataStatus() => _data;

    public IDisposable SubscribeData(Action<DataStatus> cb)
    {
        DataChanged += cb;
        cb(_data);
        return new UnsubData(() => DataChanged -= cb);
    }

    public void UpdateDataStatus(DataStatus status)
    {
        _data = status;
        DataChanged?.Invoke(_data);
    }

    public (LineSnapshot s2t, LineSnapshot skd) Read() => (_s2t, _skd);

    private sealed class Unsub : IDisposable
    {
        private readonly Action _a;
        public Unsub(Action a) { _a = a; }
        public void Dispose() { _a(); }
    }

    private sealed class UnsubDb : IDisposable
    {
        private readonly Action _a;
        public UnsubDb(Action a) { _a = a; }
        public void Dispose() { _a(); }
    }

    private sealed class UnsubData : IDisposable
    {
        private readonly Action _a;
        public UnsubData(Action a) { _a = a; }
        public void Dispose() { _a(); }
    }

}

public readonly record struct DbStatus(
    bool AndonConnected,
    bool TimerConnected,
    DateTime? LastChecked,
    string? LastError
);

public readonly record struct DataStatus(
    DateTime? LastEventTime,
    DateTime? LastChecked,
    string? LastError
);
//DashboardState.cs
