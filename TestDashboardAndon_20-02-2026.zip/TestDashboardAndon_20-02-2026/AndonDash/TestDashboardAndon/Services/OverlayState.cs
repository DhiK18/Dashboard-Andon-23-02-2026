using System;
using System.Threading.Tasks;

namespace TestDashboardAndon.Services
{
    /// <summary>
    /// UI state used by MainLayout to render fixed overlay headers
    /// (Dashboard title and Settings header + Save) outside of scrollable page content.
    /// This guarantees the headers never move when the user scrolls.
    /// </summary>
    public sealed class OverlayState
    {
        public event Action? OnChange;

        public bool ShowDashboardTitle { get; private set; }
        public bool ShowSettingsHeader { get; private set; }

        // Simple fixed page title (Problem Data Log / Data Loss, etc.)
        public bool ShowSimpleTitle { get; private set; }
        public string SimpleTitleText { get; private set; } = string.Empty;

        public string SettingsStatusText { get; private set; } = string.Empty;
        public string SettingsStatusClass { get; private set; } = "status-muted";
        public bool SettingsCanSave { get; private set; } = true;

        private Func<Task>? _settingsSaveAsync;

        public void EnableDashboardTitle(bool enabled)
        {
            if (ShowDashboardTitle == enabled) return;
            ShowDashboardTitle = enabled;
            Notify();
        }

        public void EnableSettingsHeader(bool enabled, Func<Task>? saveAsync = null)
        {
            ShowSettingsHeader = enabled;
            _settingsSaveAsync = enabled ? saveAsync : null;
            Notify();
        }

        /// <summary>
        /// Show a simple fixed top-left title rendered by MainLayout.
        /// Pass null/empty to hide it.
        /// </summary>
        public void SetSimpleTitle(string? title)
        {
            var t = (title ?? string.Empty).Trim();
            var enabled = !string.IsNullOrWhiteSpace(t);

            var changed = (ShowSimpleTitle != enabled) || (!string.Equals(SimpleTitleText, t, StringComparison.Ordinal));
            ShowSimpleTitle = enabled;
            SimpleTitleText = enabled ? t : string.Empty;

            if (changed) Notify();
        }

        public void UpdateSettingsStatus(string text, string cssClass, bool canSave)
        {
            SettingsStatusText = text ?? string.Empty;
            SettingsStatusClass = string.IsNullOrWhiteSpace(cssClass) ? "status-muted" : cssClass;
            SettingsCanSave = canSave;
            Notify();
        }

        public async Task InvokeSettingsSaveAsync()
        {
            if (_settingsSaveAsync == null) return;
            await _settingsSaveAsync();
        }

        private void Notify() => OnChange?.Invoke();
    }
}
