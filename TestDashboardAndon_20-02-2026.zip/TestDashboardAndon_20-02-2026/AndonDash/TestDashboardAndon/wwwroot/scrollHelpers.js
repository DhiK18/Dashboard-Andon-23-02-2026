﻿window.lsbuScroll = window.lsbuScroll || {
    getTop: function (el) {
        try { return el ? (el.scrollTop || 0) : 0; } catch { return 0; }
    },
    setTop: function (el, top) {
        try { if (el) el.scrollTop = top || 0; } catch { /* ignore */ }
    }
};

window.andonToggleFullscreen = async function () {
    try {
        const d = document;
        const fsEl = d.fullscreenElement || d.webkitFullscreenElement || d.mozFullScreenElement || d.msFullscreenElement;

        if (fsEl) {
            if (d.exitFullscreen) return await d.exitFullscreen();
            if (d.webkitExitFullscreen) return await d.webkitExitFullscreen();
            if (d.mozCancelFullScreen) return await d.mozCancelFullScreen();
            if (d.msExitFullscreen) return await d.msExitFullscreen();
            return;
        }

        const el = d.documentElement;
        if (el.requestFullscreen) return await el.requestFullscreen();
        if (el.webkitRequestFullscreen) return await el.webkitRequestFullscreen();
        if (el.mozRequestFullScreen) return await el.mozRequestFullScreen();
        if (el.msRequestFullscreen) return await el.msRequestFullscreen();
    } catch (e) {
        console.error('Fullscreen toggle failed:', e);
    }
};

window.andonEnterFullscreen = async function () {
    try {
        const d = document;
        const fsEl = d.fullscreenElement || d.webkitFullscreenElement || d.mozFullScreenElement || d.msFullscreenElement;
        if (fsEl) return;

        const el = d.documentElement;
        if (el.requestFullscreen) return await el.requestFullscreen();
        if (el.webkitRequestFullscreen) return await el.webkitRequestFullscreen();
        if (el.mozRequestFullScreen) return await el.mozRequestFullScreen();
        if (el.msRequestFullscreen) return await el.msRequestFullscreen();
    } catch (e) {
        console.error('Enter fullscreen failed:', e);
    }
};
