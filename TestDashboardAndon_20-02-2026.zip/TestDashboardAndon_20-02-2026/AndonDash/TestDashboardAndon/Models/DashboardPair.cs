﻿namespace TestDashboardAndon.Models;

    public sealed class DashboardPair
    {
        public LineSnapshot? s2t { get; set; }
        public LineSnapshot? skd { get; set; }
    }
