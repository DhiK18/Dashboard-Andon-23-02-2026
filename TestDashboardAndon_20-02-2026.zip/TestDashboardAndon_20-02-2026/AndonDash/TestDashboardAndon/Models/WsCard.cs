﻿namespace TestDashboardAndon.Models;
public sealed class WsCard
{
    public string Line { get; set; } = "";
    public int Ws { get; set; }

    public int ActiveProblem { get; set; } = 0;

    public DateTime? ProblemStartTime { get; set; }

    public string MachineLoss { get; set; } = "00:00:00";
    public string MaterialLoss { get; set; } = "00:00:00";
    public string OperatorLoss { get; set; } = "00:00:00";
    public string QualityLoss { get; set; } = "00:00:00";
}