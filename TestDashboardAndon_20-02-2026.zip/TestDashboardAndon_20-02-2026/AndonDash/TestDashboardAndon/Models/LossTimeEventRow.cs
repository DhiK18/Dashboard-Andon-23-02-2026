﻿namespace TestDashboardAndon.Models;
public sealed class LossTimeEventRow
{
    public int No { get; set; }

    public string Line { get; set; } = "";

    public string TwoT { get; set; } = "";

    public int WorkingStation { get; set; }

    public int Problem { get; set; }

    public int Value { get; set; }

    public DateTime Time { get; set; }
}